--
-- PostgreSQL database dump
--

\restrict jkmIIa5V9j3Zys2e1XXmPFKq8yIkB0MWndj5ZOcnPxF8nyR8rXPE7K0iXWCXrx1

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."WorkerProfile" DROP CONSTRAINT IF EXISTS "WorkerProfile_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."WorkerCategory" DROP CONSTRAINT IF EXISTS "WorkerCategory_workerProfileId_fkey";
ALTER TABLE IF EXISTS ONLY public."WorkerCategory" DROP CONSTRAINT IF EXISTS "WorkerCategory_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."Withdrawal" DROP CONSTRAINT IF EXISTS "Withdrawal_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."WalletTransaction" DROP CONSTRAINT IF EXISTS "WalletTransaction_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."VideoCall" DROP CONSTRAINT IF EXISTS "VideoCall_receiverId_fkey";
ALTER TABLE IF EXISTS ONLY public."VideoCall" DROP CONSTRAINT IF EXISTS "VideoCall_initiatorId_fkey";
ALTER TABLE IF EXISTS ONLY public."VideoCall" DROP CONSTRAINT IF EXISTS "VideoCall_bookingId_fkey";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_referredById_fkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."SavedWorker" DROP CONSTRAINT IF EXISTS "SavedWorker_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."SavedWorker" DROP CONSTRAINT IF EXISTS "SavedWorker_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."SavedJob" DROP CONSTRAINT IF EXISTS "SavedJob_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."SavedJob" DROP CONSTRAINT IF EXISTS "SavedJob_jobPostId_fkey";
ALTER TABLE IF EXISTS ONLY public."Review" DROP CONSTRAINT IF EXISTS "Review_receiverId_fkey";
ALTER TABLE IF EXISTS ONLY public."Review" DROP CONSTRAINT IF EXISTS "Review_giverId_fkey";
ALTER TABLE IF EXISTS ONLY public."Review" DROP CONSTRAINT IF EXISTS "Review_bookingId_fkey";
ALTER TABLE IF EXISTS ONLY public."Report" DROP CONSTRAINT IF EXISTS "Report_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."Report" DROP CONSTRAINT IF EXISTS "Report_reporterId_fkey";
ALTER TABLE IF EXISTS ONLY public."Refund" DROP CONSTRAINT IF EXISTS "Refund_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Refund" DROP CONSTRAINT IF EXISTS "Refund_paymentId_fkey";
ALTER TABLE IF EXISTS ONLY public."Refund" DROP CONSTRAINT IF EXISTS "Refund_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Refund" DROP CONSTRAINT IF EXISTS "Refund_bookingId_fkey";
ALTER TABLE IF EXISTS ONLY public."Refund" DROP CONSTRAINT IF EXISTS "Refund_adminId_fkey";
ALTER TABLE IF EXISTS ONLY public."Referral" DROP CONSTRAINT IF EXISTS "Referral_referrerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Referral" DROP CONSTRAINT IF EXISTS "Referral_referredId_fkey";
ALTER TABLE IF EXISTS ONLY public."PromoCode" DROP CONSTRAINT IF EXISTS "PromoCode_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public."PromoCodeUsage" DROP CONSTRAINT IF EXISTS "PromoCodeUsage_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."PromoCodeUsage" DROP CONSTRAINT IF EXISTS "PromoCodeUsage_promoCodeId_fkey";
ALTER TABLE IF EXISTS ONLY public."Post" DROP CONSTRAINT IF EXISTS "Post_repostOfId_fkey";
ALTER TABLE IF EXISTS ONLY public."Post" DROP CONSTRAINT IF EXISTS "Post_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public."PostReaction" DROP CONSTRAINT IF EXISTS "PostReaction_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."PostReaction" DROP CONSTRAINT IF EXISTS "PostReaction_postId_fkey";
ALTER TABLE IF EXISTS ONLY public."PostComment" DROP CONSTRAINT IF EXISTS "PostComment_postId_fkey";
ALTER TABLE IF EXISTS ONLY public."PostComment" DROP CONSTRAINT IF EXISTS "PostComment_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public."PostComment" DROP CONSTRAINT IF EXISTS "PostComment_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public."Portfolio" DROP CONSTRAINT IF EXISTS "Portfolio_workerProfileId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_bookingId_fkey";
ALTER TABLE IF EXISTS ONLY public."Notification" DROP CONSTRAINT IF EXISTS "Notification_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Message" DROP CONSTRAINT IF EXISTS "Message_senderId_fkey";
ALTER TABLE IF EXISTS ONLY public."Message" DROP CONSTRAINT IF EXISTS "Message_receiverId_fkey";
ALTER TABLE IF EXISTS ONLY public."Message" DROP CONSTRAINT IF EXISTS "Message_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobPost" DROP CONSTRAINT IF EXISTS "JobPost_postedByAdminId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobPost" DROP CONSTRAINT IF EXISTS "JobPost_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobPost" DROP CONSTRAINT IF EXISTS "JobPost_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCategory" DROP CONSTRAINT IF EXISTS "JobCategory_jobId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobCategory" DROP CONSTRAINT IF EXISTS "JobCategory_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobApplication" DROP CONSTRAINT IF EXISTS "JobApplication_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."JobApplication" DROP CONSTRAINT IF EXISTS "JobApplication_jobPostId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerWithdrawal" DROP CONSTRAINT IF EXISTS "HirerWithdrawal_walletId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerWithdrawal" DROP CONSTRAINT IF EXISTS "HirerWithdrawal_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerWallet" DROP CONSTRAINT IF EXISTS "HirerWallet_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerTransaction" DROP CONSTRAINT IF EXISTS "HirerTransaction_walletId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerTransaction" DROP CONSTRAINT IF EXISTS "HirerTransaction_paymentId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerTransaction" DROP CONSTRAINT IF EXISTS "HirerTransaction_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerProfile" DROP CONSTRAINT IF EXISTS "HirerProfile_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerFundingAttempt" DROP CONSTRAINT IF EXISTS "HirerFundingAttempt_walletId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerFundingAttempt" DROP CONSTRAINT IF EXISTS "HirerFundingAttempt_transactionId_fkey";
ALTER TABLE IF EXISTS ONLY public."HirerFundingAttempt" DROP CONSTRAINT IF EXISTS "HirerFundingAttempt_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Feedback" DROP CONSTRAINT IF EXISTS "Feedback_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Feedback" DROP CONSTRAINT IF EXISTS "Feedback_reviewedBy_fkey";
ALTER TABLE IF EXISTS ONLY public."FeaturedListing" DROP CONSTRAINT IF EXISTS "FeaturedListing_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."FeaturedListing" DROP CONSTRAINT IF EXISTS "FeaturedListing_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."ExternalJobClick" DROP CONSTRAINT IF EXISTS "ExternalJobClick_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."ExternalJobClick" DROP CONSTRAINT IF EXISTS "ExternalJobClick_jobPostId_fkey";
ALTER TABLE IF EXISTS ONLY public."DeviceToken" DROP CONSTRAINT IF EXISTS "DeviceToken_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Conversation" DROP CONSTRAINT IF EXISTS "Conversation_bookingId_fkey";
ALTER TABLE IF EXISTS ONLY public."ConversationUser" DROP CONSTRAINT IF EXISTS "ConversationUser_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."ConversationUser" DROP CONSTRAINT IF EXISTS "ConversationUser_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public."Certification" DROP CONSTRAINT IF EXISTS "Certification_workerProfileId_fkey";
ALTER TABLE IF EXISTS ONLY public."Category" DROP CONSTRAINT IF EXISTS "Category_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public."CampaignWithdrawal" DROP CONSTRAINT IF EXISTS "CampaignWithdrawal_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."CampaignTransaction" DROP CONSTRAINT IF EXISTS "CampaignTransaction_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."CampaignSubmission" DROP CONSTRAINT IF EXISTS "CampaignSubmission_referrerId_fkey";
ALTER TABLE IF EXISTS ONLY public."CampaignReferral" DROP CONSTRAINT IF EXISTS "CampaignReferral_submissionId_fkey";
ALTER TABLE IF EXISTS ONLY public."CampaignReferral" DROP CONSTRAINT IF EXISTS "CampaignReferral_referrerId_fkey";
ALTER TABLE IF EXISTS ONLY public."CampaignReferral" DROP CONSTRAINT IF EXISTS "CampaignReferral_referredId_fkey";
ALTER TABLE IF EXISTS ONLY public."Booking" DROP CONSTRAINT IF EXISTS "Booking_workerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Booking" DROP CONSTRAINT IF EXISTS "Booking_hirerId_fkey";
ALTER TABLE IF EXISTS ONLY public."Booking" DROP CONSTRAINT IF EXISTS "Booking_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."Availability" DROP CONSTRAINT IF EXISTS "Availability_workerProfileId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_adminId_fkey";
DROP INDEX IF EXISTS public.waitlist_entries_token_key;
DROP INDEX IF EXISTS public.waitlist_entries_status_idx;
DROP INDEX IF EXISTS public.waitlist_entries_referral_code_key;
DROP INDEX IF EXISTS public.waitlist_entries_email_key;
DROP INDEX IF EXISTS public.waitlist_entries_email_idx;
DROP INDEX IF EXISTS public.waitlist_entries_device_type_idx;
DROP INDEX IF EXISTS public.waitlist_entries_created_at_idx;
DROP INDEX IF EXISTS public.waitlist_entries_country_idx;
DROP INDEX IF EXISTS public.waitlist_email_logs_waitlist_id_idx;
DROP INDEX IF EXISTS public.waitlist_email_logs_type_idx;
DROP INDEX IF EXISTS public.waitlist_email_logs_sent_at_idx;
DROP INDEX IF EXISTS public.waitlist_email_logs_campaign_id_idx;
DROP INDEX IF EXISTS public.waitlist_campaigns_status_idx;
DROP INDEX IF EXISTS public.waitlist_campaigns_sent_at_idx;
DROP INDEX IF EXISTS public.survey_responses_status_idx;
DROP INDEX IF EXISTS public.survey_responses_email_idx;
DROP INDEX IF EXISTS public.survey_responses_created_at_idx;
DROP INDEX IF EXISTS public."WorkerProfile_userId_key";
DROP INDEX IF EXISTS public."WorkerCategory_workerProfileId_categoryId_key";
DROP INDEX IF EXISTS public."Withdrawal_reference_key";
DROP INDEX IF EXISTS public."VideoCall_roomId_key";
DROP INDEX IF EXISTS public."VideoCall_bookingId_key";
DROP INDEX IF EXISTS public."User_referralCode_key";
DROP INDEX IF EXISTS public."User_phone_key";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."SavedWorker_workerId_idx";
DROP INDEX IF EXISTS public."SavedWorker_hirerId_workerId_key";
DROP INDEX IF EXISTS public."SavedWorker_hirerId_idx";
DROP INDEX IF EXISTS public."SavedJob_workerId_jobPostId_key";
DROP INDEX IF EXISTS public."SavedJob_workerId_idx";
DROP INDEX IF EXISTS public."SavedJob_jobPostId_idx";
DROP INDEX IF EXISTS public."Review_bookingId_giverId_key";
DROP INDEX IF EXISTS public."Report_targetType_targetId_idx";
DROP INDEX IF EXISTS public."Report_status_idx";
DROP INDEX IF EXISTS public."Report_reporterId_targetType_targetId_key";
DROP INDEX IF EXISTS public."Report_reporterId_idx";
DROP INDEX IF EXISTS public."Report_createdAt_idx";
DROP INDEX IF EXISTS public."Refund_workerId_idx";
DROP INDEX IF EXISTS public."Refund_status_idx";
DROP INDEX IF EXISTS public."Refund_reference_key";
DROP INDEX IF EXISTS public."Refund_reference_idx";
DROP INDEX IF EXISTS public."Refund_paymentId_idx";
DROP INDEX IF EXISTS public."Refund_hirerId_idx";
DROP INDEX IF EXISTS public."Refund_createdAt_idx";
DROP INDEX IF EXISTS public."Refund_bookingId_idx";
DROP INDEX IF EXISTS public."Refund_adminId_idx";
DROP INDEX IF EXISTS public."Referral_referredId_key";
DROP INDEX IF EXISTS public."PromoCode_code_key";
DROP INDEX IF EXISTS public."PromoCodeUsage_userId_promoCodeId_key";
DROP INDEX IF EXISTS public."PostReaction_postId_userId_key";
DROP INDEX IF EXISTS public."Notification_userId_idx";
DROP INDEX IF EXISTS public."Notification_isRead_idx";
DROP INDEX IF EXISTS public."Notification_createdAt_idx";
DROP INDEX IF EXISTS public."JobCategory_jobId_categoryId_key";
DROP INDEX IF EXISTS public."JobApplication_jobPostId_workerId_key";
DROP INDEX IF EXISTS public."HirerWithdrawal_walletId_idx";
DROP INDEX IF EXISTS public."HirerWithdrawal_status_idx";
DROP INDEX IF EXISTS public."HirerWithdrawal_reference_key";
DROP INDEX IF EXISTS public."HirerWithdrawal_reference_idx";
DROP INDEX IF EXISTS public."HirerWithdrawal_hirerId_idx";
DROP INDEX IF EXISTS public."HirerWithdrawal_createdAt_idx";
DROP INDEX IF EXISTS public."HirerWallet_hirerId_idx";
DROP INDEX IF EXISTS public."HirerWallet_hirerId_currency_key";
DROP INDEX IF EXISTS public."HirerWallet_currency_idx";
DROP INDEX IF EXISTS public."HirerWallet_createdAt_idx";
DROP INDEX IF EXISTS public."HirerTransaction_walletId_idx";
DROP INDEX IF EXISTS public."HirerTransaction_type_idx";
DROP INDEX IF EXISTS public."HirerTransaction_status_idx";
DROP INDEX IF EXISTS public."HirerTransaction_reference_key";
DROP INDEX IF EXISTS public."HirerTransaction_reference_idx";
DROP INDEX IF EXISTS public."HirerTransaction_hirerId_idx";
DROP INDEX IF EXISTS public."HirerTransaction_createdAt_idx";
DROP INDEX IF EXISTS public."HirerProfile_userId_key";
DROP INDEX IF EXISTS public."HirerFundingAttempt_walletId_idx";
DROP INDEX IF EXISTS public."HirerFundingAttempt_status_idx";
DROP INDEX IF EXISTS public."HirerFundingAttempt_providerRef_key";
DROP INDEX IF EXISTS public."HirerFundingAttempt_providerRef_idx";
DROP INDEX IF EXISTS public."HirerFundingAttempt_hirerId_idx";
DROP INDEX IF EXISTS public."HirerFundingAttempt_createdAt_idx";
DROP INDEX IF EXISTS public."FeaturedListing_reference_key";
DROP INDEX IF EXISTS public."ExternalJobClick_userId_idx";
DROP INDEX IF EXISTS public."ExternalJobClick_type_idx";
DROP INDEX IF EXISTS public."ExternalJobClick_jobPostId_userId_type_key";
DROP INDEX IF EXISTS public."ExternalJobClick_jobPostId_idx";
DROP INDEX IF EXISTS public."DeviceToken_userId_token_key";
DROP INDEX IF EXISTS public."DeviceToken_userId_idx";
DROP INDEX IF EXISTS public."DeviceToken_token_idx";
DROP INDEX IF EXISTS public."DeviceToken_active_idx";
DROP INDEX IF EXISTS public."Conversation_bookingId_key";
DROP INDEX IF EXISTS public."ConversationUser_conversationId_userId_key";
DROP INDEX IF EXISTS public."Category_slug_key";
DROP INDEX IF EXISTS public."Category_name_key";
DROP INDEX IF EXISTS public."CampaignSubmission_referrerId_submissionDate_key";
DROP INDEX IF EXISTS public."CampaignReferral_referredId_key";
DROP INDEX IF EXISTS public."AuditLog_targetType_targetId_idx";
DROP INDEX IF EXISTS public."AuditLog_result_idx";
DROP INDEX IF EXISTS public."AuditLog_createdAt_idx";
DROP INDEX IF EXISTS public."AuditLog_adminId_idx";
DROP INDEX IF EXISTS public."AuditLog_action_idx";
DROP INDEX IF EXISTS public."AppSettings_key_key";
DROP INDEX IF EXISTS public."AppSettings_key_idx";
ALTER TABLE IF EXISTS ONLY public.waitlist_entries DROP CONSTRAINT IF EXISTS waitlist_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.waitlist_email_logs DROP CONSTRAINT IF EXISTS waitlist_email_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.waitlist_campaigns DROP CONSTRAINT IF EXISTS waitlist_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.survey_responses DROP CONSTRAINT IF EXISTS survey_responses_pkey;
ALTER TABLE IF EXISTS ONLY public."WorkerProfile" DROP CONSTRAINT IF EXISTS "WorkerProfile_pkey";
ALTER TABLE IF EXISTS ONLY public."WorkerCategory" DROP CONSTRAINT IF EXISTS "WorkerCategory_pkey";
ALTER TABLE IF EXISTS ONLY public."Withdrawal" DROP CONSTRAINT IF EXISTS "Withdrawal_pkey";
ALTER TABLE IF EXISTS ONLY public."WalletTransaction" DROP CONSTRAINT IF EXISTS "WalletTransaction_pkey";
ALTER TABLE IF EXISTS ONLY public."VideoCall" DROP CONSTRAINT IF EXISTS "VideoCall_pkey";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_pkey";
ALTER TABLE IF EXISTS ONLY public."SavedWorker" DROP CONSTRAINT IF EXISTS "SavedWorker_pkey";
ALTER TABLE IF EXISTS ONLY public."SavedJob" DROP CONSTRAINT IF EXISTS "SavedJob_pkey";
ALTER TABLE IF EXISTS ONLY public."Review" DROP CONSTRAINT IF EXISTS "Review_pkey";
ALTER TABLE IF EXISTS ONLY public."Report" DROP CONSTRAINT IF EXISTS "Report_pkey";
ALTER TABLE IF EXISTS ONLY public."Refund" DROP CONSTRAINT IF EXISTS "Refund_pkey";
ALTER TABLE IF EXISTS ONLY public."Referral" DROP CONSTRAINT IF EXISTS "Referral_pkey";
ALTER TABLE IF EXISTS ONLY public."PromoCode" DROP CONSTRAINT IF EXISTS "PromoCode_pkey";
ALTER TABLE IF EXISTS ONLY public."PromoCodeUsage" DROP CONSTRAINT IF EXISTS "PromoCodeUsage_pkey";
ALTER TABLE IF EXISTS ONLY public."Post" DROP CONSTRAINT IF EXISTS "Post_pkey";
ALTER TABLE IF EXISTS ONLY public."PostReaction" DROP CONSTRAINT IF EXISTS "PostReaction_pkey";
ALTER TABLE IF EXISTS ONLY public."PostComment" DROP CONSTRAINT IF EXISTS "PostComment_pkey";
ALTER TABLE IF EXISTS ONLY public."Portfolio" DROP CONSTRAINT IF EXISTS "Portfolio_pkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_pkey";
ALTER TABLE IF EXISTS ONLY public."Notification" DROP CONSTRAINT IF EXISTS "Notification_pkey";
ALTER TABLE IF EXISTS ONLY public."Message" DROP CONSTRAINT IF EXISTS "Message_pkey";
ALTER TABLE IF EXISTS ONLY public."JobPost" DROP CONSTRAINT IF EXISTS "JobPost_pkey";
ALTER TABLE IF EXISTS ONLY public."JobCategory" DROP CONSTRAINT IF EXISTS "JobCategory_pkey";
ALTER TABLE IF EXISTS ONLY public."JobApplication" DROP CONSTRAINT IF EXISTS "JobApplication_pkey";
ALTER TABLE IF EXISTS ONLY public."HirerWithdrawal" DROP CONSTRAINT IF EXISTS "HirerWithdrawal_pkey";
ALTER TABLE IF EXISTS ONLY public."HirerWallet" DROP CONSTRAINT IF EXISTS "HirerWallet_pkey";
ALTER TABLE IF EXISTS ONLY public."HirerTransaction" DROP CONSTRAINT IF EXISTS "HirerTransaction_pkey";
ALTER TABLE IF EXISTS ONLY public."HirerProfile" DROP CONSTRAINT IF EXISTS "HirerProfile_pkey";
ALTER TABLE IF EXISTS ONLY public."HirerFundingAttempt" DROP CONSTRAINT IF EXISTS "HirerFundingAttempt_pkey";
ALTER TABLE IF EXISTS ONLY public."Feedback" DROP CONSTRAINT IF EXISTS "Feedback_pkey";
ALTER TABLE IF EXISTS ONLY public."FeaturedListing" DROP CONSTRAINT IF EXISTS "FeaturedListing_pkey";
ALTER TABLE IF EXISTS ONLY public."ExternalJobClick" DROP CONSTRAINT IF EXISTS "ExternalJobClick_pkey";
ALTER TABLE IF EXISTS ONLY public."DeviceToken" DROP CONSTRAINT IF EXISTS "DeviceToken_pkey";
ALTER TABLE IF EXISTS ONLY public."Conversation" DROP CONSTRAINT IF EXISTS "Conversation_pkey";
ALTER TABLE IF EXISTS ONLY public."ConversationUser" DROP CONSTRAINT IF EXISTS "ConversationUser_pkey";
ALTER TABLE IF EXISTS ONLY public."Certification" DROP CONSTRAINT IF EXISTS "Certification_pkey";
ALTER TABLE IF EXISTS ONLY public."Category" DROP CONSTRAINT IF EXISTS "Category_pkey";
ALTER TABLE IF EXISTS ONLY public."CampaignWithdrawal" DROP CONSTRAINT IF EXISTS "CampaignWithdrawal_pkey";
ALTER TABLE IF EXISTS ONLY public."CampaignTransaction" DROP CONSTRAINT IF EXISTS "CampaignTransaction_pkey";
ALTER TABLE IF EXISTS ONLY public."CampaignSubmission" DROP CONSTRAINT IF EXISTS "CampaignSubmission_pkey";
ALTER TABLE IF EXISTS ONLY public."CampaignReferral" DROP CONSTRAINT IF EXISTS "CampaignReferral_pkey";
ALTER TABLE IF EXISTS ONLY public."Booking" DROP CONSTRAINT IF EXISTS "Booking_pkey";
ALTER TABLE IF EXISTS ONLY public."Availability" DROP CONSTRAINT IF EXISTS "Availability_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_pkey";
ALTER TABLE IF EXISTS ONLY public."AppSettings" DROP CONSTRAINT IF EXISTS "AppSettings_pkey";
DROP TABLE IF EXISTS public.waitlist_entries;
DROP TABLE IF EXISTS public.waitlist_email_logs;
DROP TABLE IF EXISTS public.waitlist_campaigns;
DROP TABLE IF EXISTS public.survey_responses;
DROP TABLE IF EXISTS public."WorkerProfile";
DROP TABLE IF EXISTS public."WorkerCategory";
DROP TABLE IF EXISTS public."Withdrawal";
DROP TABLE IF EXISTS public."WalletTransaction";
DROP TABLE IF EXISTS public."VideoCall";
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."Subscription";
DROP TABLE IF EXISTS public."SavedWorker";
DROP TABLE IF EXISTS public."SavedJob";
DROP TABLE IF EXISTS public."Review";
DROP TABLE IF EXISTS public."Report";
DROP TABLE IF EXISTS public."Refund";
DROP TABLE IF EXISTS public."Referral";
DROP TABLE IF EXISTS public."PromoCodeUsage";
DROP TABLE IF EXISTS public."PromoCode";
DROP TABLE IF EXISTS public."PostReaction";
DROP TABLE IF EXISTS public."PostComment";
DROP TABLE IF EXISTS public."Post";
DROP TABLE IF EXISTS public."Portfolio";
DROP TABLE IF EXISTS public."Payment";
DROP TABLE IF EXISTS public."Notification";
DROP TABLE IF EXISTS public."Message";
DROP TABLE IF EXISTS public."JobPost";
DROP TABLE IF EXISTS public."JobCategory";
DROP TABLE IF EXISTS public."JobApplication";
DROP TABLE IF EXISTS public."HirerWithdrawal";
DROP TABLE IF EXISTS public."HirerWallet";
DROP TABLE IF EXISTS public."HirerTransaction";
DROP TABLE IF EXISTS public."HirerProfile";
DROP TABLE IF EXISTS public."HirerFundingAttempt";
DROP TABLE IF EXISTS public."Feedback";
DROP TABLE IF EXISTS public."FeaturedListing";
DROP TABLE IF EXISTS public."ExternalJobClick";
DROP TABLE IF EXISTS public."DeviceToken";
DROP TABLE IF EXISTS public."ConversationUser";
DROP TABLE IF EXISTS public."Conversation";
DROP TABLE IF EXISTS public."Certification";
DROP TABLE IF EXISTS public."Category";
DROP TABLE IF EXISTS public."CampaignWithdrawal";
DROP TABLE IF EXISTS public."CampaignTransaction";
DROP TABLE IF EXISTS public."CampaignSubmission";
DROP TABLE IF EXISTS public."CampaignReferral";
DROP TABLE IF EXISTS public."Booking";
DROP TABLE IF EXISTS public."Availability";
DROP TABLE IF EXISTS public."AuditLog";
DROP TABLE IF EXISTS public."AppSettings";
DROP TYPE IF EXISTS public."WithdrawalStatus";
DROP TYPE IF EXISTS public."VerificationStatus";
DROP TYPE IF EXISTS public."SubscriptionTier";
DROP TYPE IF EXISTS public."SubscriptionStatus";
DROP TYPE IF EXISTS public."SubscriptionRole";
DROP TYPE IF EXISTS public."SalaryPeriod";
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."ReportType";
DROP TYPE IF EXISTS public."ReportStatus";
DROP TYPE IF EXISTS public."ReportReason";
DROP TYPE IF EXISTS public."ReportAction";
DROP TYPE IF EXISTS public."RefundType";
DROP TYPE IF EXISTS public."RefundStatus";
DROP TYPE IF EXISTS public."ReferralTier";
DROP TYPE IF EXISTS public."ReferralStatus";
DROP TYPE IF EXISTS public."ReactionType";
DROP TYPE IF EXISTS public."PostType";
DROP TYPE IF EXISTS public."PaymentStatus";
DROP TYPE IF EXISTS public."LocationType";
DROP TYPE IF EXISTS public."JobType";
DROP TYPE IF EXISTS public."JobPostStatus";
DROP TYPE IF EXISTS public."EducationLevel";
DROP TYPE IF EXISTS public."DurationType";
DROP TYPE IF EXISTS public."CampaignSubmissionStatus";
DROP TYPE IF EXISTS public."CampaignReferralStatus";
DROP TYPE IF EXISTS public."BudgetType";
DROP TYPE IF EXISTS public."BookingStatus";
DROP TYPE IF EXISTS public."AuditTargetType";
DROP TYPE IF EXISTS public."AuditResult";
DROP TYPE IF EXISTS public."AuditAction";
DROP TYPE IF EXISTS public."ApplicationStatus";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: ApplicationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ApplicationStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED'
);


--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditAction" AS ENUM (
    'USER_BANNED',
    'USER_UNBANNED',
    'USER_DELETED',
    'USER_ROLE_CHANGED',
    'USER_VERIFIED',
    'USER_VERIFICATION_REJECTED',
    'USER_SUSPENDED',
    'PAYMENT_RELEASED',
    'PAYMENT_REFUNDED',
    'PAYMENT_MANUAL_VERIFIED',
    'PAYMENT_MANUAL_REJECTED',
    'WITHDRAWAL_APPROVED',
    'WITHDRAWAL_REJECTED',
    'REPORT_REVIEWED',
    'REPORT_RESOLVED',
    'REPORT_DISMISSED',
    'REPORT_BULK_DISMISSED',
    'CATEGORY_CREATED',
    'CATEGORY_UPDATED',
    'CATEGORY_DELETED',
    'REVIEW_DELETED',
    'JOB_DELETED',
    'JOB_STATUS_CHANGED',
    'POST_DELETED',
    'COMMENT_DELETED',
    'FEATURED_REMOVED',
    'BOOKING_STATUS_CHANGED',
    'DISPUTE_RESOLVED',
    'CAMPAIGN_SUBMISSION_REVIEWED',
    'CAMPAIGN_WITHDRAWAL_APPROVED',
    'CAMPAIGN_WITHDRAWAL_REJECTED',
    'REFERRAL_PAYOUT_PROCESSED',
    'REFERRAL_FLAGGED',
    'SUBSCRIPTION_CANCELLED',
    'NOTIFICATION_BROADCAST',
    'ADMIN_LOGIN',
    'SETTINGS_CHANGED',
    'JOB_CREATED',
    'JOB_UPDATED'
);


--
-- Name: AuditResult; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditResult" AS ENUM (
    'SUCCESS',
    'FAILED',
    'PARTIAL'
);


--
-- Name: AuditTargetType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditTargetType" AS ENUM (
    'USER',
    'PAYMENT',
    'WITHDRAWAL',
    'BOOKING',
    'JOB_POST',
    'POST',
    'COMMENT',
    'REVIEW',
    'CATEGORY',
    'REPORT',
    'CAMPAIGN_SUBMISSION',
    'CAMPAIGN_WITHDRAWAL',
    'REFERRAL',
    'SUBSCRIPTION',
    'FEATURED_LISTING',
    'DISPUTE',
    'SYSTEM'
);


--
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'DISPUTED'
);


--
-- Name: BudgetType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BudgetType" AS ENUM (
    'FIXED',
    'HOURLY',
    'DAILY',
    'WEEKLY',
    'MONTHLY',
    'CUSTOM'
);


--
-- Name: CampaignReferralStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignReferralStatus" AS ENUM (
    'PENDING',
    'TASKS_DONE',
    'SUBMITTED',
    'APPROVED',
    'REJECTED'
);


--
-- Name: CampaignSubmissionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignSubmissionStatus" AS ENUM (
    'PENDING',
    'REVIEWING',
    'APPROVED',
    'PARTIAL',
    'REJECTED'
);


--
-- Name: DurationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DurationType" AS ENUM (
    'HOURS',
    'DAYS',
    'WEEKS',
    'MONTHS',
    'CUSTOM'
);


--
-- Name: EducationLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EducationLevel" AS ENUM (
    'HIGH_SCHOOL',
    'DIPLOMA',
    'BACHELOR',
    'MASTER',
    'DOCTORATE',
    'CERTIFICATION',
    'OTHER'
);


--
-- Name: JobPostStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobPostStatus" AS ENUM (
    'OPEN',
    'FILLED',
    'CANCELLED'
);


--
-- Name: JobType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobType" AS ENUM (
    'FULL_TIME',
    'PART_TIME',
    'CONTRACT',
    'TEMPORARY'
);


--
-- Name: LocationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LocationType" AS ENUM (
    'REMOTE',
    'ON_SITE',
    'HYBRID'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'HELD',
    'RELEASED',
    'REFUNDED',
    'FAILED'
);


--
-- Name: PostType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PostType" AS ENUM (
    'GENERAL',
    'JOB_UPDATE',
    'ACHIEVEMENT',
    'PORTFOLIO',
    'ANNOUNCEMENT',
    'HIRING'
);


--
-- Name: ReactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReactionType" AS ENUM (
    'LIKE',
    'LOVE',
    'INSIGHTFUL',
    'CELEBRATE',
    'SUPPORT'
);


--
-- Name: ReferralStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReferralStatus" AS ENUM (
    'PENDING',
    'QUALIFIED',
    'CONVERTED',
    'REWARDED',
    'EXPIRED',
    'FLAGGED'
);


--
-- Name: ReferralTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReferralTier" AS ENUM (
    'BRONZE',
    'SILVER',
    'GOLD',
    'DIAMOND'
);


--
-- Name: RefundStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RefundStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'PROCESSING',
    'COMPLETED',
    'REJECTED',
    'FAILED',
    'REVERSED',
    'DISPUTED'
);


--
-- Name: RefundType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RefundType" AS ENUM (
    'FULL',
    'PARTIAL',
    'CUSTOM_AMOUNT',
    'DISPUTE'
);


--
-- Name: ReportAction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReportAction" AS ENUM (
    'NO_ACTION',
    'WARNING_ISSUED',
    'CONTENT_REMOVED',
    'USER_SUSPENDED',
    'USER_BANNED'
);


--
-- Name: ReportReason; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReportReason" AS ENUM (
    'SPAM',
    'FAKE_PROFILE',
    'INAPPROPRIATE_CONTENT',
    'FRAUD',
    'HARASSMENT',
    'SCAM',
    'MISLEADING_INFORMATION',
    'FAKE_REVIEWS',
    'UNDERAGE_USER',
    'HATE_SPEECH',
    'OTHER'
);


--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'PENDING',
    'REVIEWING',
    'RESOLVED',
    'DISMISSED'
);


--
-- Name: ReportType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReportType" AS ENUM (
    'USER',
    'JOB_POST',
    'POST',
    'REVIEW',
    'BOOKING',
    'MESSAGE'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'HIRER',
    'WORKER',
    'ADMIN'
);


--
-- Name: SalaryPeriod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SalaryPeriod" AS ENUM (
    'HOURLY',
    'DAILY',
    'WEEKLY',
    'MONTHLY',
    'YEARLY'
);


--
-- Name: SubscriptionRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionRole" AS ENUM (
    'WORKER',
    'HIRER'
);


--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'ACTIVE',
    'CANCELLED',
    'EXPIRED',
    'PENDING'
);


--
-- Name: SubscriptionTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionTier" AS ENUM (
    'FREE',
    'PRO',
    'ENTERPRISE'
);


--
-- Name: VerificationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VerificationStatus" AS ENUM (
    'UNVERIFIED',
    'PENDING',
    'VERIFIED',
    'REJECTED'
);


--
-- Name: WithdrawalStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WithdrawalStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AppSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AppSettings" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    description text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "adminId" text NOT NULL,
    action public."AuditAction" NOT NULL,
    "targetType" public."AuditTargetType" NOT NULL,
    "targetId" text,
    description text NOT NULL,
    before jsonb,
    after jsonb,
    meta jsonb,
    result public."AuditResult" DEFAULT 'SUCCESS'::public."AuditResult" NOT NULL,
    "errorMessage" text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Availability" (
    id text NOT NULL,
    "workerProfileId" text NOT NULL,
    "dayOfWeek" integer NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL
);


--
-- Name: Booking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Booking" (
    id text NOT NULL,
    "hirerId" text NOT NULL,
    "workerId" text NOT NULL,
    "categoryId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    address text NOT NULL,
    latitude double precision,
    longitude double precision,
    "scheduledAt" timestamp(3) without time zone NOT NULL,
    "estimatedHours" double precision,
    "agreedRate" double precision NOT NULL,
    currency text NOT NULL,
    status public."BookingStatus" DEFAULT 'PENDING'::public."BookingStatus" NOT NULL,
    notes text,
    "checkInAt" timestamp(3) without time zone,
    "checkInLat" double precision,
    "checkInLng" double precision,
    "checkOutAt" timestamp(3) without time zone,
    "checkOutLat" double precision,
    "checkOutLng" double precision,
    "completedAt" timestamp(3) without time zone,
    quantity integer DEFAULT 1,
    "cancelReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    custom_label text,
    "emergencyContact" text,
    "sosActivatedAt" timestamp(3) without time zone,
    "sosLatitude" double precision,
    "sosLongitude" double precision,
    "sosResolvedAt" timestamp(3) without time zone,
    "insuranceRef" text,
    "insurancePlan" text,
    "insurancePaidAt" timestamp(3) without time zone,
    "estimatedUnit" text DEFAULT 'hours'::text,
    "estimatedValue" text,
    "isNegotiated" boolean DEFAULT false NOT NULL,
    "negotiatedRate" double precision,
    "negotiationNote" text,
    "jobType" text,
    "locationType" text,
    requirements text,
    responsibilities text,
    "disputeReason" text,
    "disputeDescription" text,
    "disputeEvidence" text[] DEFAULT ARRAY[]::text[]
);


--
-- Name: CampaignReferral; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignReferral" (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "referredId" text NOT NULL,
    code text NOT NULL,
    "submissionId" text,
    "hasDownloadedApp" boolean DEFAULT true NOT NULL,
    "hasSetupProfile" boolean DEFAULT false NOT NULL,
    "hasFollowedFb" boolean DEFAULT false NOT NULL,
    "hasFollowedIg" boolean DEFAULT false NOT NULL,
    "hasFollowedTt" boolean DEFAULT false NOT NULL,
    "fbScreenshotUrl" text,
    "igScreenshotUrl" text,
    "ttScreenshotUrl" text,
    status public."CampaignReferralStatus" DEFAULT 'PENDING'::public."CampaignReferralStatus" NOT NULL,
    "adminNote" text,
    "rewardAmount" double precision DEFAULT 100 NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    "tasksCompletedAt" timestamp(3) without time zone,
    "submittedAt" timestamp(3) without time zone,
    "reviewedAt" timestamp(3) without time zone,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignSubmission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignSubmission" (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "submissionDate" text NOT NULL,
    "totalSubmitted" integer DEFAULT 0 NOT NULL,
    "totalApproved" integer DEFAULT 0 NOT NULL,
    "totalRejected" integer DEFAULT 0 NOT NULL,
    "grossAmount" double precision DEFAULT 0 NOT NULL,
    "netAmount" double precision DEFAULT 0 NOT NULL,
    status public."CampaignSubmissionStatus" DEFAULT 'PENDING'::public."CampaignSubmissionStatus" NOT NULL,
    "adminNote" text,
    "reviewedAt" timestamp(3) without time zone,
    "reviewedById" text,
    "creditedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignTransaction" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    description text NOT NULL,
    "referralId" text,
    "submissionId" text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: CampaignWithdrawal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignWithdrawal" (
    id text NOT NULL,
    "userId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    "bankName" text NOT NULL,
    "accountNumber" text NOT NULL,
    "accountName" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "adminNote" text,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    icon text,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isUserSubmitted" boolean DEFAULT false NOT NULL,
    "submittedBy" text
);


--
-- Name: Certification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Certification" (
    id text NOT NULL,
    "workerProfileId" text NOT NULL,
    name text NOT NULL,
    "issuedBy" text NOT NULL,
    "issueDate" timestamp(3) without time zone,
    "expiryDate" timestamp(3) without time zone,
    "documentUrl" text,
    verified boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Conversation" (
    id text NOT NULL,
    "bookingId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ConversationUser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ConversationUser" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "userId" text NOT NULL
);


--
-- Name: DeviceToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DeviceToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    platform text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ExternalJobClick; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ExternalJobClick" (
    id text NOT NULL,
    "jobPostId" text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: FeaturedListing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FeaturedListing" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "categoryId" text,
    type text DEFAULT 'SEARCH_TOP'::text NOT NULL,
    price double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "startsAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    reference text NOT NULL,
    "stripeSessionId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isPaid" boolean DEFAULT false NOT NULL,
    source text
);


--
-- Name: Feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Feedback" (
    id text NOT NULL,
    type text NOT NULL,
    rating integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    email text,
    name text,
    tags text[],
    "screenUrl" text,
    "browserInfo" text,
    "userId" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "adminNotes" text,
    "reviewedAt" timestamp(3) without time zone,
    "reviewedBy" text,
    "ipAddress" text,
    "userAgent" text,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: HirerFundingAttempt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HirerFundingAttempt" (
    id text NOT NULL,
    "walletId" text NOT NULL,
    "hirerId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    provider text NOT NULL,
    "providerRef" text NOT NULL,
    status text DEFAULT 'INITIATED'::text NOT NULL,
    "redirectUrl" text,
    "callbackData" jsonb,
    "paymentLink" text,
    "transactionId" text,
    meta jsonb,
    "expiresAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: HirerProfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HirerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "companyName" text,
    "companySize" text,
    website text,
    "totalSpent" double precision DEFAULT 0 NOT NULL,
    "totalHires" integer DEFAULT 0 NOT NULL,
    "avgRating" double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: HirerTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HirerTransaction" (
    id text NOT NULL,
    "walletId" text NOT NULL,
    "hirerId" text NOT NULL,
    type text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    fee double precision DEFAULT 0 NOT NULL,
    "netAmount" double precision NOT NULL,
    reference text NOT NULL,
    status text NOT NULL,
    description text,
    "balanceBefore" double precision,
    "balanceAfter" double precision,
    "completedAt" timestamp(3) without time zone,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paymentId" text
);


--
-- Name: HirerWallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HirerWallet" (
    id text NOT NULL,
    "hirerId" text NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    "totalDeposited" double precision DEFAULT 0 NOT NULL,
    "totalSpent" double precision DEFAULT 0 NOT NULL,
    "totalWithdrawn" double precision DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastTransactionAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: HirerWithdrawal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HirerWithdrawal" (
    id text NOT NULL,
    "walletId" text NOT NULL,
    "hirerId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    fee double precision DEFAULT 0 NOT NULL,
    "netAmount" double precision NOT NULL,
    "bankName" text NOT NULL,
    "accountNumber" text NOT NULL,
    "accountName" text NOT NULL,
    "bankCode" text,
    reference text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "failureReason" text,
    "processedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: JobApplication; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobApplication" (
    id text NOT NULL,
    "jobPostId" text NOT NULL,
    "workerId" text NOT NULL,
    message text,
    status public."ApplicationStatus" DEFAULT 'PENDING'::public."ApplicationStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: JobCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobCategory" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    "categoryId" text NOT NULL
);


--
-- Name: JobPost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobPost" (
    id text NOT NULL,
    "hirerId" text NOT NULL,
    "categoryId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    address text,
    latitude double precision,
    longitude double precision,
    "scheduledAt" timestamp(3) without time zone NOT NULL,
    "estimatedHours" double precision,
    budget double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    notes text,
    status public."JobPostStatus" DEFAULT 'OPEN'::public."JobPostStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "estimatedUnit" text DEFAULT 'hours'::text,
    "estimatedValue" text,
    "jobType" public."JobType" DEFAULT 'FULL_TIME'::public."JobType" NOT NULL,
    "locationType" public."LocationType" DEFAULT 'REMOTE'::public."LocationType" NOT NULL,
    "budgetType" public."BudgetType" DEFAULT 'FIXED'::public."BudgetType" NOT NULL,
    "durationType" public."DurationType" DEFAULT 'HOURS'::public."DurationType" NOT NULL,
    "durationValue" text,
    skills text[] DEFAULT ARRAY[]::text[],
    "applicationUrl" text,
    "sourcePlatform" text,
    "applicationEmail" text,
    "applicationWhatsApp" text,
    "applicationPhone" text,
    "minQualification" text,
    "experienceLevel" text,
    "experienceLength" text,
    "languageRequirement" text DEFAULT 'English'::text,
    "workingHours" text,
    "applicantLocation" text,
    responsibilities text,
    requirements text,
    "expiryDate" timestamp(3) without time zone,
    "isExternal" boolean DEFAULT false NOT NULL,
    "postedByAdminId" text,
    "companyName" text,
    "salaryText" text,
    "salaryAmount" double precision,
    "salaryMin" double precision,
    "salaryMax" double precision,
    "salaryCurrency" text,
    "salaryPeriod" public."SalaryPeriod",
    "educationLevel" public."EducationLevel"
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    content text NOT NULL,
    "fileUrl" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    type text NOT NULL,
    data jsonb,
    icon text,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "userId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "platformFee" double precision NOT NULL,
    "workerPayout" double precision NOT NULL,
    "workerCurrency" text,
    "workerPayoutLocal" double precision,
    "exchangeRate" double precision DEFAULT 1,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    provider text NOT NULL,
    "providerRef" text,
    "escrowReleasedAt" timestamp(3) without time zone,
    "refundedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "bankName" text,
    "accountName" text,
    "accountNumber" text,
    "bankTransferRef" text,
    "bankTransferProof" text,
    "cryptoNetwork" text,
    "cryptoTxHash" text,
    "cryptoWallet" text,
    "cryptoAmount" double precision,
    "cryptoCurrency" text,
    "feePhase" integer DEFAULT 1,
    notes text,
    "referralDeduct" double precision DEFAULT 0,
    "walletPaymentId" text
);


--
-- Name: Portfolio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Portfolio" (
    id text NOT NULL,
    "workerProfileId" text NOT NULL,
    title text NOT NULL,
    description text,
    "imageUrl" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Post; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    "authorId" text NOT NULL,
    content text NOT NULL,
    images text[] DEFAULT ARRAY[]::text[],
    type public."PostType" DEFAULT 'GENERAL'::public."PostType" NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "repostOfId" text,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PostComment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PostComment" (
    id text NOT NULL,
    "postId" text NOT NULL,
    "authorId" text NOT NULL,
    content text NOT NULL,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PostReaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PostReaction" (
    id text NOT NULL,
    "postId" text NOT NULL,
    "userId" text NOT NULL,
    type public."ReactionType" DEFAULT 'LIKE'::public."ReactionType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PromoCode; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PromoCode" (
    id text NOT NULL,
    code text NOT NULL,
    description text,
    "discountType" text DEFAULT 'PERCENT'::text NOT NULL,
    "discountValue" double precision NOT NULL,
    "maxUses" integer,
    "usedCount" integer DEFAULT 0 NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "applicableTo" text,
    "minPlanAmount" double precision DEFAULT 0 NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PromoCodeUsage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PromoCodeUsage" (
    id text NOT NULL,
    "promoCodeId" text NOT NULL,
    "userId" text NOT NULL,
    "planId" text NOT NULL,
    "discountAmt" double precision NOT NULL,
    "originalAmt" double precision NOT NULL,
    "finalAmt" double precision NOT NULL,
    reference text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Referral; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Referral" (
    id text NOT NULL,
    "referrerId" text NOT NULL,
    "referredId" text NOT NULL,
    code text NOT NULL,
    status public."ReferralStatus" DEFAULT 'PENDING'::public."ReferralStatus" NOT NULL,
    "referredRole" public."Role" NOT NULL,
    "referrerBonus" double precision DEFAULT 0 NOT NULL,
    "refereePerk" text NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "qualifiedAt" timestamp(3) without time zone,
    "convertedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Refund; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Refund" (
    id text NOT NULL,
    reference text NOT NULL,
    "bookingId" text NOT NULL,
    "paymentId" text NOT NULL,
    "hirerId" text NOT NULL,
    "workerId" text,
    "adminId" text,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    "platformFeeRefunded" double precision DEFAULT 0 NOT NULL,
    "workerAmountDeducted" double precision DEFAULT 0 NOT NULL,
    "refundType" public."RefundType" DEFAULT 'FULL'::public."RefundType" NOT NULL,
    percentage double precision,
    reason text NOT NULL,
    "adminNotes" text,
    status public."RefundStatus" DEFAULT 'PENDING'::public."RefundStatus" NOT NULL,
    "processedAt" timestamp(3) without time zone,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Report" (
    id text NOT NULL,
    "reporterId" text NOT NULL,
    "targetType" public."ReportType" NOT NULL,
    "targetId" text NOT NULL,
    reason public."ReportReason" NOT NULL,
    description text,
    evidence text[] DEFAULT ARRAY[]::text[],
    status public."ReportStatus" DEFAULT 'PENDING'::public."ReportStatus" NOT NULL,
    "adminNote" text,
    "actionTaken" public."ReportAction",
    "reviewedById" text,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Review" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "giverId" text NOT NULL,
    "receiverId" text NOT NULL,
    rating integer NOT NULL,
    comment text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SavedJob; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SavedJob" (
    id text NOT NULL,
    "workerId" text NOT NULL,
    "jobPostId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SavedWorker; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SavedWorker" (
    id text NOT NULL,
    "hirerId" text NOT NULL,
    "workerId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "userId" text NOT NULL,
    tier public."SubscriptionTier" DEFAULT 'FREE'::public."SubscriptionTier" NOT NULL,
    role public."SubscriptionRole" NOT NULL,
    status public."SubscriptionStatus" DEFAULT 'ACTIVE'::public."SubscriptionStatus" NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "autoRenew" boolean DEFAULT false NOT NULL,
    reference text,
    "stripeSessionId" text,
    "stripeSubscriptionId" text,
    "paystackSubscriptionCode" text,
    "paystackCustomerCode" text,
    "paystackPlanCode" text,
    "paystackEmailToken" text,
    "nextPaymentDate" timestamp(3) without time zone,
    "paystackStatus" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    phone text,
    password text NOT NULL,
    role public."Role" NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    avatar text,
    bio text,
    country text,
    city text,
    state text,
    address text,
    latitude double precision,
    longitude double precision,
    currency text DEFAULT 'USD'::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "isPhoneVerified" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isBanned" boolean DEFAULT false NOT NULL,
    "emailVerifyToken" text,
    "passwordResetToken" text,
    "passwordResetExpiry" timestamp(3) without time zone,
    "refreshToken" text,
    "lastSeen" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    theme text DEFAULT 'system'::text,
    "notifBookings" boolean DEFAULT true NOT NULL,
    "notifMessages" boolean DEFAULT true NOT NULL,
    "notifPayments" boolean DEFAULT true NOT NULL,
    "notifReviews" boolean DEFAULT true NOT NULL,
    "notifMarketing" boolean DEFAULT false NOT NULL,
    "profileVisible" boolean DEFAULT true NOT NULL,
    "showPhone" boolean DEFAULT false NOT NULL,
    "showLocation" boolean DEFAULT true NOT NULL,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "dashboardCurrency" text DEFAULT 'USD'::text,
    "paymentCurrency" text DEFAULT 'USD'::text,
    "showEmail" boolean DEFAULT false NOT NULL,
    "showGender" boolean DEFAULT false NOT NULL,
    "defaultEstUnit" text,
    "defaultEstValue" text,
    gender text,
    "referralCode" text,
    "referredById" text,
    "walletBalance" double precision DEFAULT 0 NOT NULL,
    "walletLifetimeTotal" double precision DEFAULT 0 NOT NULL,
    "referralTier" public."ReferralTier" DEFAULT 'BRONZE'::public."ReferralTier" NOT NULL,
    "totalReferrals" integer DEFAULT 0 NOT NULL,
    "successfulReferrals" integer DEFAULT 0 NOT NULL,
    "campaignWalletBalance" double precision DEFAULT 0 NOT NULL,
    "campaignWalletLifetimeTotal" double precision DEFAULT 0 NOT NULL,
    "withdrawalPin" text,
    "withdrawalPinSet" boolean DEFAULT false NOT NULL,
    "withdrawalPinAttempts" integer DEFAULT 0 NOT NULL,
    "withdrawalPinLockedUntil" timestamp(3) without time zone
);


--
-- Name: VideoCall; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VideoCall" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "initiatorId" text NOT NULL,
    "receiverId" text NOT NULL,
    "roomId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "endedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: WalletTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WalletTransaction" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    description text NOT NULL,
    "referralId" text,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Withdrawal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Withdrawal" (
    id text NOT NULL,
    "workerId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'NGN'::text NOT NULL,
    method text NOT NULL,
    destination text NOT NULL,
    details jsonb NOT NULL,
    reference text NOT NULL,
    status public."WithdrawalStatus" DEFAULT 'PENDING'::public."WithdrawalStatus" NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "failureNote" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: WorkerCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkerCategory" (
    id text NOT NULL,
    "workerProfileId" text NOT NULL,
    "categoryId" text NOT NULL,
    "isPrimary" boolean DEFAULT false NOT NULL
);


--
-- Name: WorkerProfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    description text,
    "hourlyRate" double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "yearsExperience" integer DEFAULT 0 NOT NULL,
    "serviceRadius" integer DEFAULT 25 NOT NULL,
    "isAvailable" boolean DEFAULT true NOT NULL,
    "verificationStatus" public."VerificationStatus" DEFAULT 'UNVERIFIED'::public."VerificationStatus" NOT NULL,
    "idDocument" text,
    "videoIntroUrl" text,
    "backgroundCheck" boolean DEFAULT false NOT NULL,
    "totalEarnings" double precision DEFAULT 0 NOT NULL,
    "completedJobs" integer DEFAULT 0 NOT NULL,
    "responseRate" double precision DEFAULT 0 NOT NULL,
    "avgRating" double precision DEFAULT 0 NOT NULL,
    "totalReviews" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "weeklyRate" double precision,
    "monthlyRate" double precision,
    "yearlyRate" double precision,
    "customRate" double precision,
    "customRateLabel" text,
    "pricingNote" text,
    "profileCurrency" text DEFAULT 'USD'::text,
    "dailyRate" double precision
);


--
-- Name: survey_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.survey_responses (
    id text NOT NULL,
    role text,
    industry text,
    experience_level text,
    biggest_challenge text,
    desired_feature text,
    biggest_concern text,
    hear_about text,
    email text,
    full_name text,
    phone_number text,
    location text,
    additional_feedback text,
    rating integer DEFAULT 0,
    status text DEFAULT 'PENDING'::text NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: waitlist_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waitlist_campaigns (
    id text NOT NULL,
    title text NOT NULL,
    subject text NOT NULL,
    content text NOT NULL,
    preview_text text,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    sent_at timestamp(3) without time zone,
    scheduled_for timestamp(3) without time zone,
    recipient_count integer DEFAULT 0 NOT NULL,
    opened_count integer DEFAULT 0 NOT NULL,
    clicked_count integer DEFAULT 0 NOT NULL,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: waitlist_email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waitlist_email_logs (
    id text NOT NULL,
    waitlist_id text NOT NULL,
    campaign_id text,
    email text NOT NULL,
    type text NOT NULL,
    subject text NOT NULL,
    opened boolean DEFAULT false NOT NULL,
    opened_at timestamp(3) without time zone,
    clicked boolean DEFAULT false NOT NULL,
    clicked_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    error text
);


--
-- Name: waitlist_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waitlist_entries (
    id text NOT NULL,
    email text NOT NULL,
    full_name text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    ip_address text,
    country text,
    region text,
    city text,
    latitude double precision,
    longitude double precision,
    timezone text,
    postal_code text,
    device_type text,
    device_brand text,
    device_model text,
    os_name text,
    os_version text,
    browser_name text,
    browser_version text,
    user_agent text,
    referral_code text,
    referred_by text,
    token text,
    token_expires_at timestamp(3) without time zone,
    confirmed_at timestamp(3) without time zone,
    unlocked_benefits text[],
    benefit_unlocked_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: AppSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AppSettings" (id, key, value, description, meta, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "adminId", action, "targetType", "targetId", description, before, after, meta, result, "errorMessage", "ipAddress", "userAgent", "createdAt") FROM stdin;
\.


--
-- Data for Name: Availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Availability" (id, "workerProfileId", "dayOfWeek", "startTime", "endTime", "isAvailable") FROM stdin;
\.


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Booking" (id, "hirerId", "workerId", "categoryId", title, description, address, latitude, longitude, "scheduledAt", "estimatedHours", "agreedRate", currency, status, notes, "checkInAt", "checkInLat", "checkInLng", "checkOutAt", "checkOutLat", "checkOutLng", "completedAt", quantity, "cancelReason", "createdAt", "updatedAt", custom_label, "emergencyContact", "sosActivatedAt", "sosLatitude", "sosLongitude", "sosResolvedAt", "insuranceRef", "insurancePlan", "insurancePaidAt", "estimatedUnit", "estimatedValue", "isNegotiated", "negotiatedRate", "negotiationNote", "jobType", "locationType", requirements, responsibilities, "disputeReason", "disputeDescription", "disputeEvidence") FROM stdin;
\.


--
-- Data for Name: CampaignReferral; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignReferral" (id, "referrerId", "referredId", code, "submissionId", "hasDownloadedApp", "hasSetupProfile", "hasFollowedFb", "hasFollowedIg", "hasFollowedTt", "fbScreenshotUrl", "igScreenshotUrl", "ttScreenshotUrl", status, "adminNote", "rewardAmount", currency, "tasksCompletedAt", "submittedAt", "reviewedAt", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignSubmission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignSubmission" (id, "referrerId", "submissionDate", "totalSubmitted", "totalApproved", "totalRejected", "grossAmount", "netAmount", status, "adminNote", "reviewedAt", "reviewedById", "creditedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignTransaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignTransaction" (id, "userId", type, amount, currency, description, "referralId", "submissionId", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: CampaignWithdrawal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignWithdrawal" (id, "userId", amount, currency, "bankName", "accountNumber", "accountName", status, "adminNote", "processedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Category" (id, name, slug, description, icon, "parentId", "createdAt", "isUserSubmitted", "submittedBy") FROM stdin;
\.


--
-- Data for Name: Certification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Certification" (id, "workerProfileId", name, "issuedBy", "issueDate", "expiryDate", "documentUrl", verified, "createdAt") FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Conversation" (id, "bookingId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ConversationUser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ConversationUser" (id, "conversationId", "userId") FROM stdin;
\.


--
-- Data for Name: DeviceToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DeviceToken" (id, "userId", token, platform, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ExternalJobClick; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ExternalJobClick" (id, "jobPostId", "userId", type, "createdAt") FROM stdin;
\.


--
-- Data for Name: FeaturedListing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FeaturedListing" (id, "userId", "categoryId", type, price, currency, "startsAt", "expiresAt", "isActive", reference, "stripeSessionId", "createdAt", "isPaid", source) FROM stdin;
\.


--
-- Data for Name: Feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Feedback" (id, type, rating, title, description, email, name, tags, "screenUrl", "browserInfo", "userId", status, "adminNotes", "reviewedAt", "reviewedBy", "ipAddress", "userAgent", "submittedAt", "createdAt", "updatedAt") FROM stdin;
cmtz9ougx0001yh67iemkbnyl	praise	3	dndndnd	ndndndndndndn	\N	fdndn	{}	http://localhost:3000/landingpage	{"userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36","screen":"1440x900","language":"en-US","platform":"MacIntel"}	\N	PENDING	\N	\N	\N	102.91.102.254	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36	2026-09-13 03:41:29.1	2026-09-13 03:41:29.793	2026-09-13 03:41:29.793
cmtz9ppl00003yh67yvscjdel	bug	4	fhdndn	dndgndndndnd	nnamdionwukwe@gmail.com	MIKE	{}	http://localhost:3000/landingpage	{"userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36","screen":"1440x900","language":"en-US","platform":"MacIntel"}	\N	PENDING	\N	\N	\N	102.91.102.254	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36	2026-09-13 03:42:09.498	2026-09-13 03:42:10.116	2026-09-13 03:42:10.116
\.


--
-- Data for Name: HirerFundingAttempt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HirerFundingAttempt" (id, "walletId", "hirerId", amount, currency, provider, "providerRef", status, "redirectUrl", "callbackData", "paymentLink", "transactionId", meta, "expiresAt", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: HirerProfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HirerProfile" (id, "userId", "companyName", "companySize", website, "totalSpent", "totalHires", "avgRating", "createdAt", "updatedAt") FROM stdin;
7b364e6e-de8a-4d71-a9fa-d5fdecf0feae	72007838-045f-4fea-aee7-b1f7be232ac9	\N	\N	\N	0	0	0	2026-09-13 13:42:49.475	2026-09-13 13:42:49.475
\.


--
-- Data for Name: HirerTransaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HirerTransaction" (id, "walletId", "hirerId", type, amount, currency, fee, "netAmount", reference, status, description, "balanceBefore", "balanceAfter", "completedAt", meta, "createdAt", "updatedAt", "paymentId") FROM stdin;
\.


--
-- Data for Name: HirerWallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HirerWallet" (id, "hirerId", currency, balance, "totalDeposited", "totalSpent", "totalWithdrawn", "isActive", "lastTransactionAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: HirerWithdrawal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HirerWithdrawal" (id, "walletId", "hirerId", amount, currency, fee, "netAmount", "bankName", "accountNumber", "accountName", "bankCode", reference, status, "failureReason", "processedAt", "completedAt", meta, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: JobApplication; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobApplication" (id, "jobPostId", "workerId", message, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: JobCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobCategory" (id, "jobId", "categoryId") FROM stdin;
\.


--
-- Data for Name: JobPost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobPost" (id, "hirerId", "categoryId", title, description, address, latitude, longitude, "scheduledAt", "estimatedHours", budget, currency, notes, status, "createdAt", "updatedAt", "estimatedUnit", "estimatedValue", "jobType", "locationType", "budgetType", "durationType", "durationValue", skills, "applicationUrl", "sourcePlatform", "applicationEmail", "applicationWhatsApp", "applicationPhone", "minQualification", "experienceLevel", "experienceLength", "languageRequirement", "workingHours", "applicantLocation", responsibilities, requirements, "expiryDate", "isExternal", "postedByAdminId", "companyName", "salaryText", "salaryAmount", "salaryMin", "salaryMax", "salaryCurrency", "salaryPeriod", "educationLevel") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, "conversationId", "senderId", "receiverId", content, "fileUrl", "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Notification" (id, "userId", title, body, type, data, icon, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "bookingId", "userId", amount, currency, "platformFee", "workerPayout", "workerCurrency", "workerPayoutLocal", "exchangeRate", status, provider, "providerRef", "escrowReleasedAt", "refundedAt", "createdAt", "updatedAt", "bankName", "accountName", "accountNumber", "bankTransferRef", "bankTransferProof", "cryptoNetwork", "cryptoTxHash", "cryptoWallet", "cryptoAmount", "cryptoCurrency", "feePhase", notes, "referralDeduct", "walletPaymentId") FROM stdin;
\.


--
-- Data for Name: Portfolio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Portfolio" (id, "workerProfileId", title, description, "imageUrl", "createdAt") FROM stdin;
\.


--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Post" (id, "authorId", content, images, type, "isPublic", "repostOfId", "viewCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PostComment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PostComment" (id, "postId", "authorId", content, "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PostReaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PostReaction" (id, "postId", "userId", type, "createdAt") FROM stdin;
\.


--
-- Data for Name: PromoCode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PromoCode" (id, code, description, "discountType", "discountValue", "maxUses", "usedCount", "expiresAt", "isActive", "applicableTo", "minPlanAmount", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PromoCodeUsage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PromoCodeUsage" (id, "promoCodeId", "userId", "planId", "discountAmt", "originalAmt", "finalAmt", reference, "createdAt") FROM stdin;
\.


--
-- Data for Name: Referral; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Referral" (id, "referrerId", "referredId", code, status, "referredRole", "referrerBonus", "refereePerk", currency, "paidAt", "qualifiedAt", "convertedAt", "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Refund; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Refund" (id, reference, "bookingId", "paymentId", "hirerId", "workerId", "adminId", amount, currency, "platformFeeRefunded", "workerAmountDeducted", "refundType", percentage, reason, "adminNotes", status, "processedAt", meta, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Report" (id, "reporterId", "targetType", "targetId", reason, description, evidence, status, "adminNote", "actionTaken", "reviewedById", "resolvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Review" (id, "bookingId", "giverId", "receiverId", rating, comment, "createdAt") FROM stdin;
\.


--
-- Data for Name: SavedJob; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SavedJob" (id, "workerId", "jobPostId", "createdAt") FROM stdin;
\.


--
-- Data for Name: SavedWorker; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SavedWorker" (id, "hirerId", "workerId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Subscription" (id, "userId", tier, role, status, price, currency, "startedAt", "expiresAt", "autoRenew", reference, "stripeSessionId", "stripeSubscriptionId", "paystackSubscriptionCode", "paystackCustomerCode", "paystackPlanCode", "paystackEmailToken", "nextPaymentDate", "paystackStatus", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, phone, password, role, "firstName", "lastName", avatar, bio, country, city, state, address, latitude, longitude, currency, language, "isEmailVerified", "isPhoneVerified", "isActive", "isBanned", "emailVerifyToken", "passwordResetToken", "passwordResetExpiry", "refreshToken", "lastSeen", "createdAt", "updatedAt", theme, "notifBookings", "notifMessages", "notifPayments", "notifReviews", "notifMarketing", "profileVisible", "showPhone", "showLocation", "twoFactorEnabled", "dashboardCurrency", "paymentCurrency", "showEmail", "showGender", "defaultEstUnit", "defaultEstValue", gender, "referralCode", "referredById", "walletBalance", "walletLifetimeTotal", "referralTier", "totalReferrals", "successfulReferrals", "campaignWalletBalance", "campaignWalletLifetimeTotal", "withdrawalPin", "withdrawalPinSet", "withdrawalPinAttempts", "withdrawalPinLockedUntil") FROM stdin;
72007838-045f-4fea-aee7-b1f7be232ac9	nnamdionwukwe@gmail.com	08037748573	$2b$12$fxhzwr7Cnd95SA9n60QgZeC/EKVr2XnmdRHXP6wEPLsGTk4pN3UqG	HIRER	Solace	King	\N	\N	Nigeria	Abuja	\N	\N	\N	\N	USD	en	f	f	t	f	e6cd4c235d8aea53a10304b600b35559bb0fafe4650c77194e8a60ad216434e9	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjcyMDA3ODM4LTA0NWYtNGZlYS1hZWU3LWIxZjdiZTIzMmFjOSIsImlhdCI6MTc4OTMwNjk2OSwiZXhwIjoxNzkxODk4OTY5fQ.0YRVUaeSlF0VA5atvmFdPTvqZJ7l-dZzfAn0ifAN7_w	\N	2026-09-13 13:42:49.469	2026-09-13 13:43:24.778	system	t	t	t	t	f	t	f	t	f	USD	USD	f	f	\N	\N	\N	\N	\N	0	0	BRONZE	0	0	0	0	\N	f	0	\N
\.


--
-- Data for Name: VideoCall; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VideoCall" (id, "bookingId", "initiatorId", "receiverId", "roomId", status, "startedAt", "endedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: WalletTransaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WalletTransaction" (id, "userId", type, amount, currency, description, "referralId", meta, "createdAt") FROM stdin;
\.


--
-- Data for Name: Withdrawal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Withdrawal" (id, "workerId", amount, currency, method, destination, details, reference, status, "completedAt", "failureNote", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkerCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WorkerCategory" (id, "workerProfileId", "categoryId", "isPrimary") FROM stdin;
\.


--
-- Data for Name: WorkerProfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WorkerProfile" (id, "userId", title, description, "hourlyRate", currency, "yearsExperience", "serviceRadius", "isAvailable", "verificationStatus", "idDocument", "videoIntroUrl", "backgroundCheck", "totalEarnings", "completedJobs", "responseRate", "avgRating", "totalReviews", "createdAt", "updatedAt", "weeklyRate", "monthlyRate", "yearlyRate", "customRate", "customRateLabel", "pricingNote", "profileCurrency", "dailyRate") FROM stdin;
\.


--
-- Data for Name: survey_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.survey_responses (id, role, industry, experience_level, biggest_challenge, desired_feature, biggest_concern, hear_about, email, full_name, phone_number, location, additional_feedback, rating, status, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: waitlist_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waitlist_campaigns (id, title, subject, content, preview_text, status, sent_at, scheduled_for, recipient_count, opened_count, clicked_count, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: waitlist_email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waitlist_email_logs (id, waitlist_id, campaign_id, email, type, subject, opened, opened_at, clicked, clicked_at, sent_at, error) FROM stdin;
\.


--
-- Data for Name: waitlist_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waitlist_entries (id, email, full_name, status, ip_address, country, region, city, latitude, longitude, timezone, postal_code, device_type, device_brand, device_model, os_name, os_version, browser_name, browser_version, user_agent, referral_code, referred_by, token, token_expires_at, confirmed_at, unlocked_benefits, benefit_unlocked_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: AppSettings AppSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AppSettings"
    ADD CONSTRAINT "AppSettings_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Availability Availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Availability"
    ADD CONSTRAINT "Availability_pkey" PRIMARY KEY (id);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: CampaignReferral CampaignReferral_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignReferral"
    ADD CONSTRAINT "CampaignReferral_pkey" PRIMARY KEY (id);


--
-- Name: CampaignSubmission CampaignSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignSubmission"
    ADD CONSTRAINT "CampaignSubmission_pkey" PRIMARY KEY (id);


--
-- Name: CampaignTransaction CampaignTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignTransaction"
    ADD CONSTRAINT "CampaignTransaction_pkey" PRIMARY KEY (id);


--
-- Name: CampaignWithdrawal CampaignWithdrawal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignWithdrawal"
    ADD CONSTRAINT "CampaignWithdrawal_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: Certification Certification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Certification"
    ADD CONSTRAINT "Certification_pkey" PRIMARY KEY (id);


--
-- Name: ConversationUser ConversationUser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConversationUser"
    ADD CONSTRAINT "ConversationUser_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: DeviceToken DeviceToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_pkey" PRIMARY KEY (id);


--
-- Name: ExternalJobClick ExternalJobClick_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ExternalJobClick"
    ADD CONSTRAINT "ExternalJobClick_pkey" PRIMARY KEY (id);


--
-- Name: FeaturedListing FeaturedListing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeaturedListing"
    ADD CONSTRAINT "FeaturedListing_pkey" PRIMARY KEY (id);


--
-- Name: Feedback Feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_pkey" PRIMARY KEY (id);


--
-- Name: HirerFundingAttempt HirerFundingAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerFundingAttempt"
    ADD CONSTRAINT "HirerFundingAttempt_pkey" PRIMARY KEY (id);


--
-- Name: HirerProfile HirerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerProfile"
    ADD CONSTRAINT "HirerProfile_pkey" PRIMARY KEY (id);


--
-- Name: HirerTransaction HirerTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerTransaction"
    ADD CONSTRAINT "HirerTransaction_pkey" PRIMARY KEY (id);


--
-- Name: HirerWallet HirerWallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerWallet"
    ADD CONSTRAINT "HirerWallet_pkey" PRIMARY KEY (id);


--
-- Name: HirerWithdrawal HirerWithdrawal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerWithdrawal"
    ADD CONSTRAINT "HirerWithdrawal_pkey" PRIMARY KEY (id);


--
-- Name: JobApplication JobApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobApplication"
    ADD CONSTRAINT "JobApplication_pkey" PRIMARY KEY (id);


--
-- Name: JobCategory JobCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCategory"
    ADD CONSTRAINT "JobCategory_pkey" PRIMARY KEY (id);


--
-- Name: JobPost JobPost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPost"
    ADD CONSTRAINT "JobPost_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Portfolio Portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Portfolio"
    ADD CONSTRAINT "Portfolio_pkey" PRIMARY KEY (id);


--
-- Name: PostComment PostComment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_pkey" PRIMARY KEY (id);


--
-- Name: PostReaction PostReaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostReaction"
    ADD CONSTRAINT "PostReaction_pkey" PRIMARY KEY (id);


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: PromoCodeUsage PromoCodeUsage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromoCodeUsage"
    ADD CONSTRAINT "PromoCodeUsage_pkey" PRIMARY KEY (id);


--
-- Name: PromoCode PromoCode_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromoCode"
    ADD CONSTRAINT "PromoCode_pkey" PRIMARY KEY (id);


--
-- Name: Referral Referral_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Referral"
    ADD CONSTRAINT "Referral_pkey" PRIMARY KEY (id);


--
-- Name: Refund Refund_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_pkey" PRIMARY KEY (id);


--
-- Name: Report Report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_pkey" PRIMARY KEY (id);


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY (id);


--
-- Name: SavedJob SavedJob_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SavedJob"
    ADD CONSTRAINT "SavedJob_pkey" PRIMARY KEY (id);


--
-- Name: SavedWorker SavedWorker_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SavedWorker"
    ADD CONSTRAINT "SavedWorker_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: VideoCall VideoCall_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VideoCall"
    ADD CONSTRAINT "VideoCall_pkey" PRIMARY KEY (id);


--
-- Name: WalletTransaction WalletTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Withdrawal Withdrawal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Withdrawal"
    ADD CONSTRAINT "Withdrawal_pkey" PRIMARY KEY (id);


--
-- Name: WorkerCategory WorkerCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerCategory"
    ADD CONSTRAINT "WorkerCategory_pkey" PRIMARY KEY (id);


--
-- Name: WorkerProfile WorkerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerProfile"
    ADD CONSTRAINT "WorkerProfile_pkey" PRIMARY KEY (id);


--
-- Name: survey_responses survey_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.survey_responses
    ADD CONSTRAINT survey_responses_pkey PRIMARY KEY (id);


--
-- Name: waitlist_campaigns waitlist_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_campaigns
    ADD CONSTRAINT waitlist_campaigns_pkey PRIMARY KEY (id);


--
-- Name: waitlist_email_logs waitlist_email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_email_logs
    ADD CONSTRAINT waitlist_email_logs_pkey PRIMARY KEY (id);


--
-- Name: waitlist_entries waitlist_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_entries
    ADD CONSTRAINT waitlist_entries_pkey PRIMARY KEY (id);


--
-- Name: AppSettings_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AppSettings_key_idx" ON public."AppSettings" USING btree (key);


--
-- Name: AppSettings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AppSettings_key_key" ON public."AppSettings" USING btree (key);


--
-- Name: AuditLog_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_action_idx" ON public."AuditLog" USING btree (action);


--
-- Name: AuditLog_adminId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_adminId_idx" ON public."AuditLog" USING btree ("adminId");


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt" DESC);


--
-- Name: AuditLog_result_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_result_idx" ON public."AuditLog" USING btree (result);


--
-- Name: AuditLog_targetType_targetId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_targetType_targetId_idx" ON public."AuditLog" USING btree ("targetType", "targetId");


--
-- Name: CampaignReferral_referredId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "CampaignReferral_referredId_key" ON public."CampaignReferral" USING btree ("referredId");


--
-- Name: CampaignSubmission_referrerId_submissionDate_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "CampaignSubmission_referrerId_submissionDate_key" ON public."CampaignSubmission" USING btree ("referrerId", "submissionDate");


--
-- Name: Category_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Category_name_key" ON public."Category" USING btree (name);


--
-- Name: Category_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Category_slug_key" ON public."Category" USING btree (slug);


--
-- Name: ConversationUser_conversationId_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ConversationUser_conversationId_userId_key" ON public."ConversationUser" USING btree ("conversationId", "userId");


--
-- Name: Conversation_bookingId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Conversation_bookingId_key" ON public."Conversation" USING btree ("bookingId");


--
-- Name: DeviceToken_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DeviceToken_active_idx" ON public."DeviceToken" USING btree (active);


--
-- Name: DeviceToken_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DeviceToken_token_idx" ON public."DeviceToken" USING btree (token);


--
-- Name: DeviceToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DeviceToken_userId_idx" ON public."DeviceToken" USING btree ("userId");


--
-- Name: DeviceToken_userId_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DeviceToken_userId_token_key" ON public."DeviceToken" USING btree ("userId", token);


--
-- Name: ExternalJobClick_jobPostId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ExternalJobClick_jobPostId_idx" ON public."ExternalJobClick" USING btree ("jobPostId");


--
-- Name: ExternalJobClick_jobPostId_userId_type_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ExternalJobClick_jobPostId_userId_type_key" ON public."ExternalJobClick" USING btree ("jobPostId", "userId", type);


--
-- Name: ExternalJobClick_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ExternalJobClick_type_idx" ON public."ExternalJobClick" USING btree (type);


--
-- Name: ExternalJobClick_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ExternalJobClick_userId_idx" ON public."ExternalJobClick" USING btree ("userId");


--
-- Name: FeaturedListing_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "FeaturedListing_reference_key" ON public."FeaturedListing" USING btree (reference);


--
-- Name: HirerFundingAttempt_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerFundingAttempt_createdAt_idx" ON public."HirerFundingAttempt" USING btree ("createdAt");


--
-- Name: HirerFundingAttempt_hirerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerFundingAttempt_hirerId_idx" ON public."HirerFundingAttempt" USING btree ("hirerId");


--
-- Name: HirerFundingAttempt_providerRef_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerFundingAttempt_providerRef_idx" ON public."HirerFundingAttempt" USING btree ("providerRef");


--
-- Name: HirerFundingAttempt_providerRef_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "HirerFundingAttempt_providerRef_key" ON public."HirerFundingAttempt" USING btree ("providerRef");


--
-- Name: HirerFundingAttempt_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerFundingAttempt_status_idx" ON public."HirerFundingAttempt" USING btree (status);


--
-- Name: HirerFundingAttempt_walletId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerFundingAttempt_walletId_idx" ON public."HirerFundingAttempt" USING btree ("walletId");


--
-- Name: HirerProfile_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "HirerProfile_userId_key" ON public."HirerProfile" USING btree ("userId");


--
-- Name: HirerTransaction_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerTransaction_createdAt_idx" ON public."HirerTransaction" USING btree ("createdAt");


--
-- Name: HirerTransaction_hirerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerTransaction_hirerId_idx" ON public."HirerTransaction" USING btree ("hirerId");


--
-- Name: HirerTransaction_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerTransaction_reference_idx" ON public."HirerTransaction" USING btree (reference);


--
-- Name: HirerTransaction_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "HirerTransaction_reference_key" ON public."HirerTransaction" USING btree (reference);


--
-- Name: HirerTransaction_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerTransaction_status_idx" ON public."HirerTransaction" USING btree (status);


--
-- Name: HirerTransaction_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerTransaction_type_idx" ON public."HirerTransaction" USING btree (type);


--
-- Name: HirerTransaction_walletId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerTransaction_walletId_idx" ON public."HirerTransaction" USING btree ("walletId");


--
-- Name: HirerWallet_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWallet_createdAt_idx" ON public."HirerWallet" USING btree ("createdAt");


--
-- Name: HirerWallet_currency_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWallet_currency_idx" ON public."HirerWallet" USING btree (currency);


--
-- Name: HirerWallet_hirerId_currency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "HirerWallet_hirerId_currency_key" ON public."HirerWallet" USING btree ("hirerId", currency);


--
-- Name: HirerWallet_hirerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWallet_hirerId_idx" ON public."HirerWallet" USING btree ("hirerId");


--
-- Name: HirerWithdrawal_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWithdrawal_createdAt_idx" ON public."HirerWithdrawal" USING btree ("createdAt");


--
-- Name: HirerWithdrawal_hirerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWithdrawal_hirerId_idx" ON public."HirerWithdrawal" USING btree ("hirerId");


--
-- Name: HirerWithdrawal_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWithdrawal_reference_idx" ON public."HirerWithdrawal" USING btree (reference);


--
-- Name: HirerWithdrawal_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "HirerWithdrawal_reference_key" ON public."HirerWithdrawal" USING btree (reference);


--
-- Name: HirerWithdrawal_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWithdrawal_status_idx" ON public."HirerWithdrawal" USING btree (status);


--
-- Name: HirerWithdrawal_walletId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HirerWithdrawal_walletId_idx" ON public."HirerWithdrawal" USING btree ("walletId");


--
-- Name: JobApplication_jobPostId_workerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "JobApplication_jobPostId_workerId_key" ON public."JobApplication" USING btree ("jobPostId", "workerId");


--
-- Name: JobCategory_jobId_categoryId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "JobCategory_jobId_categoryId_key" ON public."JobCategory" USING btree ("jobId", "categoryId");


--
-- Name: Notification_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_createdAt_idx" ON public."Notification" USING btree ("createdAt");


--
-- Name: Notification_isRead_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_isRead_idx" ON public."Notification" USING btree ("isRead");


--
-- Name: Notification_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_userId_idx" ON public."Notification" USING btree ("userId");


--
-- Name: PostReaction_postId_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PostReaction_postId_userId_key" ON public."PostReaction" USING btree ("postId", "userId");


--
-- Name: PromoCodeUsage_userId_promoCodeId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PromoCodeUsage_userId_promoCodeId_key" ON public."PromoCodeUsage" USING btree ("userId", "promoCodeId");


--
-- Name: PromoCode_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PromoCode_code_key" ON public."PromoCode" USING btree (code);


--
-- Name: Referral_referredId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Referral_referredId_key" ON public."Referral" USING btree ("referredId");


--
-- Name: Refund_adminId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_adminId_idx" ON public."Refund" USING btree ("adminId");


--
-- Name: Refund_bookingId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_bookingId_idx" ON public."Refund" USING btree ("bookingId");


--
-- Name: Refund_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_createdAt_idx" ON public."Refund" USING btree ("createdAt" DESC);


--
-- Name: Refund_hirerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_hirerId_idx" ON public."Refund" USING btree ("hirerId");


--
-- Name: Refund_paymentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_paymentId_idx" ON public."Refund" USING btree ("paymentId");


--
-- Name: Refund_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_reference_idx" ON public."Refund" USING btree (reference);


--
-- Name: Refund_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Refund_reference_key" ON public."Refund" USING btree (reference);


--
-- Name: Refund_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_status_idx" ON public."Refund" USING btree (status);


--
-- Name: Refund_workerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Refund_workerId_idx" ON public."Refund" USING btree ("workerId");


--
-- Name: Report_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Report_createdAt_idx" ON public."Report" USING btree ("createdAt" DESC);


--
-- Name: Report_reporterId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Report_reporterId_idx" ON public."Report" USING btree ("reporterId");


--
-- Name: Report_reporterId_targetType_targetId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Report_reporterId_targetType_targetId_key" ON public."Report" USING btree ("reporterId", "targetType", "targetId");


--
-- Name: Report_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Report_status_idx" ON public."Report" USING btree (status);


--
-- Name: Report_targetType_targetId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Report_targetType_targetId_idx" ON public."Report" USING btree ("targetType", "targetId");


--
-- Name: Review_bookingId_giverId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Review_bookingId_giverId_key" ON public."Review" USING btree ("bookingId", "giverId");


--
-- Name: SavedJob_jobPostId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SavedJob_jobPostId_idx" ON public."SavedJob" USING btree ("jobPostId");


--
-- Name: SavedJob_workerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SavedJob_workerId_idx" ON public."SavedJob" USING btree ("workerId");


--
-- Name: SavedJob_workerId_jobPostId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SavedJob_workerId_jobPostId_key" ON public."SavedJob" USING btree ("workerId", "jobPostId");


--
-- Name: SavedWorker_hirerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SavedWorker_hirerId_idx" ON public."SavedWorker" USING btree ("hirerId");


--
-- Name: SavedWorker_hirerId_workerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SavedWorker_hirerId_workerId_key" ON public."SavedWorker" USING btree ("hirerId", "workerId");


--
-- Name: SavedWorker_workerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SavedWorker_workerId_idx" ON public."SavedWorker" USING btree ("workerId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: User_referralCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_referralCode_key" ON public."User" USING btree ("referralCode");


--
-- Name: VideoCall_bookingId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VideoCall_bookingId_key" ON public."VideoCall" USING btree ("bookingId");


--
-- Name: VideoCall_roomId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "VideoCall_roomId_key" ON public."VideoCall" USING btree ("roomId");


--
-- Name: Withdrawal_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Withdrawal_reference_key" ON public."Withdrawal" USING btree (reference);


--
-- Name: WorkerCategory_workerProfileId_categoryId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "WorkerCategory_workerProfileId_categoryId_key" ON public."WorkerCategory" USING btree ("workerProfileId", "categoryId");


--
-- Name: WorkerProfile_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "WorkerProfile_userId_key" ON public."WorkerProfile" USING btree ("userId");


--
-- Name: survey_responses_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX survey_responses_created_at_idx ON public.survey_responses USING btree (created_at);


--
-- Name: survey_responses_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX survey_responses_email_idx ON public.survey_responses USING btree (email);


--
-- Name: survey_responses_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX survey_responses_status_idx ON public.survey_responses USING btree (status);


--
-- Name: waitlist_campaigns_sent_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_campaigns_sent_at_idx ON public.waitlist_campaigns USING btree (sent_at);


--
-- Name: waitlist_campaigns_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_campaigns_status_idx ON public.waitlist_campaigns USING btree (status);


--
-- Name: waitlist_email_logs_campaign_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_email_logs_campaign_id_idx ON public.waitlist_email_logs USING btree (campaign_id);


--
-- Name: waitlist_email_logs_sent_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_email_logs_sent_at_idx ON public.waitlist_email_logs USING btree (sent_at);


--
-- Name: waitlist_email_logs_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_email_logs_type_idx ON public.waitlist_email_logs USING btree (type);


--
-- Name: waitlist_email_logs_waitlist_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_email_logs_waitlist_id_idx ON public.waitlist_email_logs USING btree (waitlist_id);


--
-- Name: waitlist_entries_country_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_entries_country_idx ON public.waitlist_entries USING btree (country);


--
-- Name: waitlist_entries_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_entries_created_at_idx ON public.waitlist_entries USING btree (created_at);


--
-- Name: waitlist_entries_device_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_entries_device_type_idx ON public.waitlist_entries USING btree (device_type);


--
-- Name: waitlist_entries_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_entries_email_idx ON public.waitlist_entries USING btree (email);


--
-- Name: waitlist_entries_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX waitlist_entries_email_key ON public.waitlist_entries USING btree (email);


--
-- Name: waitlist_entries_referral_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX waitlist_entries_referral_code_key ON public.waitlist_entries USING btree (referral_code);


--
-- Name: waitlist_entries_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waitlist_entries_status_idx ON public.waitlist_entries USING btree (status);


--
-- Name: waitlist_entries_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX waitlist_entries_token_key ON public.waitlist_entries USING btree (token);


--
-- Name: AuditLog AuditLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Availability Availability_workerProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Availability"
    ADD CONSTRAINT "Availability_workerProfileId_fkey" FOREIGN KEY ("workerProfileId") REFERENCES public."WorkerProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Booking Booking_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignReferral CampaignReferral_referredId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignReferral"
    ADD CONSTRAINT "CampaignReferral_referredId_fkey" FOREIGN KEY ("referredId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignReferral CampaignReferral_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignReferral"
    ADD CONSTRAINT "CampaignReferral_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignReferral CampaignReferral_submissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignReferral"
    ADD CONSTRAINT "CampaignReferral_submissionId_fkey" FOREIGN KEY ("submissionId") REFERENCES public."CampaignSubmission"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CampaignSubmission CampaignSubmission_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignSubmission"
    ADD CONSTRAINT "CampaignSubmission_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignTransaction CampaignTransaction_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignTransaction"
    ADD CONSTRAINT "CampaignTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignWithdrawal CampaignWithdrawal_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignWithdrawal"
    ADD CONSTRAINT "CampaignWithdrawal_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Category Category_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Certification Certification_workerProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Certification"
    ADD CONSTRAINT "Certification_workerProfileId_fkey" FOREIGN KEY ("workerProfileId") REFERENCES public."WorkerProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationUser ConversationUser_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConversationUser"
    ADD CONSTRAINT "ConversationUser_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationUser ConversationUser_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConversationUser"
    ADD CONSTRAINT "ConversationUser_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Conversation Conversation_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DeviceToken DeviceToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ExternalJobClick ExternalJobClick_jobPostId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ExternalJobClick"
    ADD CONSTRAINT "ExternalJobClick_jobPostId_fkey" FOREIGN KEY ("jobPostId") REFERENCES public."JobPost"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ExternalJobClick ExternalJobClick_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ExternalJobClick"
    ADD CONSTRAINT "ExternalJobClick_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FeaturedListing FeaturedListing_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeaturedListing"
    ADD CONSTRAINT "FeaturedListing_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FeaturedListing FeaturedListing_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeaturedListing"
    ADD CONSTRAINT "FeaturedListing_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Feedback Feedback_reviewedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_reviewedBy_fkey" FOREIGN KEY ("reviewedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Feedback Feedback_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: HirerFundingAttempt HirerFundingAttempt_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerFundingAttempt"
    ADD CONSTRAINT "HirerFundingAttempt_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HirerFundingAttempt HirerFundingAttempt_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerFundingAttempt"
    ADD CONSTRAINT "HirerFundingAttempt_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public."HirerTransaction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: HirerFundingAttempt HirerFundingAttempt_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerFundingAttempt"
    ADD CONSTRAINT "HirerFundingAttempt_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."HirerWallet"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HirerProfile HirerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerProfile"
    ADD CONSTRAINT "HirerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HirerTransaction HirerTransaction_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerTransaction"
    ADD CONSTRAINT "HirerTransaction_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HirerTransaction HirerTransaction_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerTransaction"
    ADD CONSTRAINT "HirerTransaction_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: HirerTransaction HirerTransaction_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerTransaction"
    ADD CONSTRAINT "HirerTransaction_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."HirerWallet"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HirerWallet HirerWallet_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerWallet"
    ADD CONSTRAINT "HirerWallet_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HirerWithdrawal HirerWithdrawal_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerWithdrawal"
    ADD CONSTRAINT "HirerWithdrawal_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HirerWithdrawal HirerWithdrawal_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HirerWithdrawal"
    ADD CONSTRAINT "HirerWithdrawal_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."HirerWallet"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobApplication JobApplication_jobPostId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobApplication"
    ADD CONSTRAINT "JobApplication_jobPostId_fkey" FOREIGN KEY ("jobPostId") REFERENCES public."JobPost"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JobApplication JobApplication_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobApplication"
    ADD CONSTRAINT "JobApplication_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JobCategory JobCategory_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCategory"
    ADD CONSTRAINT "JobCategory_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobCategory JobCategory_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobCategory"
    ADD CONSTRAINT "JobCategory_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."JobPost"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JobPost JobPost_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPost"
    ADD CONSTRAINT "JobPost_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobPost JobPost_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPost"
    ADD CONSTRAINT "JobPost_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JobPost JobPost_postedByAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPost"
    ADD CONSTRAINT "JobPost_postedByAdminId_fkey" FOREIGN KEY ("postedByAdminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Portfolio Portfolio_workerProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Portfolio"
    ADD CONSTRAINT "Portfolio_workerProfileId_fkey" FOREIGN KEY ("workerProfileId") REFERENCES public."WorkerProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostComment PostComment_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostComment PostComment_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."PostComment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PostComment PostComment_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostComment"
    ADD CONSTRAINT "PostComment_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostReaction PostReaction_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostReaction"
    ADD CONSTRAINT "PostReaction_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostReaction PostReaction_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostReaction"
    ADD CONSTRAINT "PostReaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_repostOfId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_repostOfId_fkey" FOREIGN KEY ("repostOfId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromoCodeUsage PromoCodeUsage_promoCodeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromoCodeUsage"
    ADD CONSTRAINT "PromoCodeUsage_promoCodeId_fkey" FOREIGN KEY ("promoCodeId") REFERENCES public."PromoCode"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromoCodeUsage PromoCodeUsage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromoCodeUsage"
    ADD CONSTRAINT "PromoCodeUsage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromoCode PromoCode_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromoCode"
    ADD CONSTRAINT "PromoCode_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Referral Referral_referredId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Referral"
    ADD CONSTRAINT "Referral_referredId_fkey" FOREIGN KEY ("referredId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Referral Referral_referrerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Referral"
    ADD CONSTRAINT "Referral_referrerId_fkey" FOREIGN KEY ("referrerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Refund Refund_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Refund Refund_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Refund Refund_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Refund Refund_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Refund Refund_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Refund"
    ADD CONSTRAINT "Refund_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Report Report_reporterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_reporterId_fkey" FOREIGN KEY ("reporterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Review Review_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Review Review_giverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_giverId_fkey" FOREIGN KEY ("giverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Review Review_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SavedJob SavedJob_jobPostId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SavedJob"
    ADD CONSTRAINT "SavedJob_jobPostId_fkey" FOREIGN KEY ("jobPostId") REFERENCES public."JobPost"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedJob SavedJob_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SavedJob"
    ADD CONSTRAINT "SavedJob_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedWorker SavedWorker_hirerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SavedWorker"
    ADD CONSTRAINT "SavedWorker_hirerId_fkey" FOREIGN KEY ("hirerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedWorker SavedWorker_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SavedWorker"
    ADD CONSTRAINT "SavedWorker_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscription Subscription_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_referredById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_referredById_fkey" FOREIGN KEY ("referredById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: VideoCall VideoCall_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VideoCall"
    ADD CONSTRAINT "VideoCall_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: VideoCall VideoCall_initiatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VideoCall"
    ADD CONSTRAINT "VideoCall_initiatorId_fkey" FOREIGN KEY ("initiatorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: VideoCall VideoCall_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VideoCall"
    ADD CONSTRAINT "VideoCall_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WalletTransaction WalletTransaction_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Withdrawal Withdrawal_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Withdrawal"
    ADD CONSTRAINT "Withdrawal_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkerCategory WorkerCategory_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerCategory"
    ADD CONSTRAINT "WorkerCategory_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WorkerCategory WorkerCategory_workerProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerCategory"
    ADD CONSTRAINT "WorkerCategory_workerProfileId_fkey" FOREIGN KEY ("workerProfileId") REFERENCES public."WorkerProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkerProfile WorkerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkerProfile"
    ADD CONSTRAINT "WorkerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict jkmIIa5V9j3Zys2e1XXmPFKq8yIkB0MWndj5ZOcnPxF8nyR8rXPE7K0iXWCXrx1

